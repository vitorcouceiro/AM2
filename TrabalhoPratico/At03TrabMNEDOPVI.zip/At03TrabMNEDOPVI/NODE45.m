function [t,y] = NODE45(f,a,b,n,y0)
% Utilização da função do matlab ODE45 para resolução numérica de EDO/PVI
% y'=f(t,y), t=[a,b], y(a)=y0
%
%INPUT:
%   f - função da EDO y'=f(t,y)
%   [a,b] - intervalo de valores da variável independente t
%   n - núnmero de subintervalos ou iterações do método
%   y0 - aproximação inicial y(a)=y0
%OUTPUT:
%   t - vetor do intervalo [a,b] discretizado 
%   y - vetor das soluções aproximadas do PVI em cada um dos t(i)
%
%   28/03/2024 Davi Gama       a2022107363.isec.pt
%   28/03/2024 Vitor Couceiro  a2022136345@isec.pt
%   28/03/2024 Tiago Manata   a2023147352@isec.pt

h = (b-a)/n;
t = a:h:b;

[~,y] = ode45(f, t, y0); % Aproximação através da função ODE45 e colocação dos valores no vetor y
y = y';       
                             
end

