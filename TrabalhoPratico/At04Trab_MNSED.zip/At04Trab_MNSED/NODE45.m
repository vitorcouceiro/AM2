function [t,u,v] = NODE45(f,g,a,b,n,u0,v0)
    % y'=f(t,y), t=[a,b], y(a)=y0
    %
    % INPUT:
    %   f - função da EDO para du/dt = f(t,u,v)
    %   g - função da EDO para dv/dt = g(t,u,v)
    %   [a,b] - intervalo de valores da variável independente t
    %   n - número de subintervalos ou iterações do método
    %   u0 - aproximação inicial para u(a)
    %   v0 - aproximação inicial para v(a)
    % OUTPUT:
    %   t - vetor do intervalo [a,b] discretizado 
    %   u - vetor das soluções aproximadas de u(t) em cada um dos t(i)
    %   v - vetor das soluções aproximadas de v(t) em cada um dos t(i)
    %
    %   28/03/2024 Davi Gama       a2022107363.isec.pt
    %   28/03/2024 Vitor Couceiro  a2022136345@isec.pt
    %   28/03/2024 Tiago Manata   a2023147352@isec.pt

    % Definindo o passo
    h = (b-a)/n;
    t = a:h:b;

    % Definindo condições iniciais
    y0 = [u0; v0];

    % Resolvendo o sistema de EDOs com ode45
    [t,Y] = ode45(@(t, y) [f(t, y(1), y(2)); g(t, y(1), y(2))], t, y0);

    % Separando as soluções para u e v
    u = Y(:, 1)';
    v = Y(:, 2)';
end
