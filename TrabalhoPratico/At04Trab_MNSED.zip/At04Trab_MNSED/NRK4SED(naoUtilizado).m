function [t,u,v] = NRK4SED(f,g,a,b,n,u0,v0)

%   04/05/2024 Davi Gama       a2022107363.isec.pt
%   04/05/2024 Vitor Couceiro  a2022136345@isec.pt
%   04/05/2024 Tiago Manata   a2023147352@isec.pt
    
h = (b-a)/n;
t = a:h:b;
    
u = zeros(1, n + 1);
v = zeros(1, n + 1);
    
u(1) = u0;
v(1) = v0;
    
for i = 1: n
    k1u = h * f(t(i), u(i), v(i));
    k1v = h * g(t(i), u(i), v(i));
        
    k2u = h * f(t(i) + (h/2), u(i) + (1/2) * k1u, v(i) + (1/2) * k1v);
    k2v = h * g(t(i) + (h/2), u(i) + (1/2) * k1u, v(i) + (1/2) * k1v);
        
    k3u = h * f(t(i) + (h/2), u(i) + (1/2) * k2u, v(i) + (1/2) * k2v);
    k3v = h * g(t(i) + (h/2), u(i) + (1/2) * k2u, v(i) + (1/2) * k2v);
        
    k4u = h * f(t(i + 1), u(i) + k3u, v(i) + k3v);
    k4v = h * g(t(i + 1), u(i) + k3u, v(i) + k3v);
        
    u(i + 1) = u(i) + (1/6) * (k1u + 2 * k2u + 2 * k3u + k4u);
    v(i + 1) = v(i) + (1/6) * (k1v + 2 * k2v + 2 * k3v + k4v);
end
end
